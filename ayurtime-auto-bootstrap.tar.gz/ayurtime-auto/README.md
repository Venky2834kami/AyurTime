# AyurTime Auto Bootstrap via GitHub Actions

This package adds a GitHub Actions workflow that can automatically create the AyurTime Phase 1 MVP milestone, default labels, and Week 1 issues in the repository.

## What it does
- Creates milestone: **AyurTime MVP – Phase 1 (30 days)**
- Creates default labels if missing
- Creates 6 Week-1 MVP issues if missing
- Avoids duplicate creation by checking existing labels/issues first

## What it does NOT fully automate by default
- Creating a modern GitHub Project board and adding issues into it may require broader project permissions than the default `GITHUB_TOKEN` provides, depending on repository/project setup and whether the project is personal or organization-owned.[web:103][web:109][web:116]
- This package therefore automates milestone/labels/issues first, which are supported with issue write permissions.[web:117][web:96][web:105]

## How to use
1. Copy `.github/workflows/bootstrap-ayurtime-mvp.yml` into your repo.
2. Copy `scripts/bootstrap-ayurtime-mvp.sh` into your repo.
3. Commit and push both files.
4. In GitHub, open **Actions** in your repo.
5. Open **Bootstrap AyurTime MVP**.
6. Click **Run workflow**.
7. Keep defaults or adjust the milestone title.
8. Run it.

## Required permissions
The workflow uses `secrets.GITHUB_TOKEN` and declares `issues: write`, which GitHub documents as a valid way to create issues from Actions.[web:117][web:106]

## Optional project-board automation later
If you want, a second workflow can be added later to automatically add newly created issues to a GitHub Project using GraphQL or actions like `actions/add-to-project`, which GitHub documents for projects automation.[web:103][web:113][web:109]
